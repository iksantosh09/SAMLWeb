/**
 * Spring Data JPA repositories.
 */
package com.jnj.saml.repository;

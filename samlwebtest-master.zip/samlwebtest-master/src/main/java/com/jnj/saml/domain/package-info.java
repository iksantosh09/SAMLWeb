/**
 * JPA domain objects.
 */
package com.jnj.saml.domain;

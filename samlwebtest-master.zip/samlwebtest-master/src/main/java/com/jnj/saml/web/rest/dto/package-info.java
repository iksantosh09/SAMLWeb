/**
 * Data Transfer Objects used by Spring MVC REST controllers.
 */
package com.jnj.saml.web.rest.dto;

/* globals $ */
'use strict';

angular.module('samlwebtestApp')
    .directive('samlwebtestAppPagination', function() {
        return {
            templateUrl: 'scripts/components/form/pagination.html'
        };
    });

/* globals $ */
'use strict';

angular.module('samlwebtestApp')
    .directive('samlwebtestAppPager', function() {
        return {
            templateUrl: 'scripts/components/form/pager.html'
        };
    });
